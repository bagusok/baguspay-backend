-- AlterEnum
ALTER TYPE "deposit_status" ADD VALUE 'PROCESS';
