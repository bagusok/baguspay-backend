-- AlterTable
ALTER TABLE "Transactions" ADD COLUMN     "input_data" TEXT,
ADD COLUMN     "notes" TEXT,
ADD COLUMN     "output_data" TEXT;
