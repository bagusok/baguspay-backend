-- AlterEnum
ALTER TYPE "payment_method_type" ADD VALUE 'TRANSFER_PULSA';
