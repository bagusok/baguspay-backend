-- AlterTable
ALTER TABLE "payment_method" ADD COLUMN     "image" TEXT;
