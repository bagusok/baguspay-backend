-- AlterTable
ALTER TABLE "services" ADD COLUMN     "input_field_one_label" TEXT,
ADD COLUMN     "input_field_three_label" TEXT,
ADD COLUMN     "input_field_two_label" TEXT,
ADD COLUMN     "publisher" TEXT;
