-- AlterEnum
ALTER TYPE "PaymentMethodProvider" ADD VALUE 'SALDO';
