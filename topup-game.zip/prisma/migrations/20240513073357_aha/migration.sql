-- AlterTable
ALTER TABLE "Transactions" ADD COLUMN     "sn_ref" TEXT;
