-- AlterTable
ALTER TABLE "services" ADD COLUMN     "meta_desc" TEXT,
ADD COLUMN     "meta_name" TEXT,
ADD COLUMN     "meta_tags" TEXT;
